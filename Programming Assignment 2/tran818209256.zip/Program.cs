﻿/// <summary>
/// Name: Bao Tran
/// Redid: 818209256
/// Date: 9.26.17
/// This assignment was completed from: Memory, MS website for file I/O, and Newtonsoft website for JSON write
/// </summary>
namespace Programming_Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            var newGame = new TicTacToe();

            newGame.DisplayMainMenu();
        }
    }
}